<?php
include 'config.php';

$content = file_get_contents("php://input");
$update = json_decode($content, true);

// ফাস্টার এপিআই রেসপন্সের জন্য ফাংশন
function botRequest($method, $data = []) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/$method";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

// মেম্বারশিপ চেক (Fast)
function isJoined($chat_id) {
    global $channelUsername;
    $res = botRequest("getChatMember", ['chat_id' => $channelUsername, 'user_id' => $chat_id]);
    $status = $res['result']['status'] ?? 'left';
    return in_array($status, ['member', 'administrator', 'creator']);
}

// ১. বাটন ক্লিকের তথ্য (Callback) প্রসেস
if (isset($update['callback_query'])) {
    $callback = $update['callback_query'];
    $callback_id = $callback['id'];
    $callback_data = $callback['data'];
    $chat_id = $callback['message']['chat']['id'];
    $name = $callback['from']['first_name'] ?? "User";

    if ($callback_data == 'check_join') {
        if (isJoined($chat_id)) {
            botRequest("answerCallbackQuery", ['callback_query_id' => $callback_id, 'text' => "✅ Success!"]);
            
            $user = $conn->query("SELECT * FROM users WHERE chat_id = $chat_id")->fetch_assoc();
            if ($user && $user['is_joined'] == 0) {
                $ref_by = $user['ref_by'];
                if ($ref_by && $ref_by != $chat_id) {
                    $ref_set = $conn->query("SELECT refer_coin FROM settings WHERE id = 1")->fetch_assoc();
                    $ref_bonus = $ref_set['refer_coin'] ?? 1;
                    $conn->query("UPDATE users SET coins = coins + $ref_bonus WHERE chat_id = $ref_by");
                    sendMessage($ref_by, "🎁 Referral Bonus! You earned $ref_bonus coins from $name.");
                }
                $conn->query("UPDATE users SET is_joined = 1 WHERE chat_id = $chat_id");
            }

            $userMenu = json_encode(['keyboard' => [[['text' => 'SMS Send'], ['text' => 'Account']], [['text' => 'Refer'], ['text' => 'Bonus']], [['text' => 'Redeem Code'], ['text' => 'Buy Coin']]], 'resize_keyboard' => true]);
            sendMessage($chat_id, "Welcome back $name! You can now use the bot.", $userMenu);
        } else {
            botRequest("answerCallbackQuery", ['callback_query_id' => $callback_id, 'text' => "❌ You haven't joined yet!", 'show_alert' => true]);
        }
    }
    exit;
}

if (!isset($update['message'])) exit;

$message_data = $update['message'];
$chat_id = $message_data['chat']['id'];
$text = $message_data['text'] ?? "";
$name = $message_data['from']['first_name'] ?? "User";

// ২. ইউজার চেক ও ইনসার্ট
$user_check = $conn->query("SELECT * FROM users WHERE chat_id = $chat_id");
if ($user_check->num_rows == 0) {
    $ref_by = (strpos($text, "/start ") === 0) ? str_replace("/start ", "", $text) : null;
    $conn->query("INSERT INTO users (chat_id, name, coins, ref_by, is_joined) VALUES ($chat_id, '$name', 0, '$ref_by', 0)");
    $user = ['chat_id' => $chat_id, 'name' => $name, 'coins' => 0, 'total_sms' => 0, 'step' => 'none', 'is_banned' => 0, 'is_joined' => 0];
} else {
    $user = $user_check->fetch_assoc();
}

if ($user['is_banned'] == 1) {
    sendMessage($chat_id, "❌ You are banned from using this bot.");
    exit;
}

// ৩. ফোর্স জয়েন চেক
if (!isJoined($chat_id)) {
    $joinBtn = json_encode(['inline_keyboard' => [[['text' => '📢 Join Our Channel', 'url' => 'https://t.me/'.str_replace('@','',$channelUsername)]], [['text' => '✅ Joined (Check)', 'callback_data' => 'check_join']]]]);
    sendMessage($chat_id, "⚠️ <b>Access Denied!</b>\n\nYou must join our channel to use this bot.", $joinBtn);
    exit;
}

include 'admin.php';

// ৪. কিবোর্ড ও মেইন ফাংশনালিটি
$userMenu = json_encode(['keyboard' => [[['text' => 'SMS Send'], ['text' => 'Account']], [['text' => 'Refer'], ['text' => 'Bonus']], [['text' => 'Redeem Code'], ['text' => 'Buy Coin']]], 'resize_keyboard' => true]);

if (strpos($text, "/start") === 0) {
    $conn->query("UPDATE users SET step = 'none' WHERE chat_id = $chat_id");
    sendMessage($chat_id, "Welcome $name! Choose an option:", $userMenu);
} 

elseif ($text == "Account") {
    $user = $conn->query("SELECT * FROM users WHERE chat_id = $chat_id")->fetch_assoc();
    sendMessage($chat_id, "👤 <b>Account Info</b>\n\n🆔 ID: $chat_id\n💰 Balance: {$user['coins']} Coins\n📨 Sent SMS: {$user['total_sms']}");
}

elseif ($text == "Refer") {
    $ref_link = "https://t.me/YOUR_BOT_USERNAME?start=$chat_id"; 
    sendMessage($chat_id, "📢 <b>Your Referral Link:</b>\n\n$ref_link\n\nShare this link to earn free coins!");
}

elseif ($text == "Bonus") {
    $today = date('Y-m-d');
    if ($user['last_bonus'] == $today) {
        sendMessage($chat_id, "❌ You already claimed your bonus today!");
    } else {
        $settings = $conn->query("SELECT daily_bonus FROM settings WHERE id = 1")->fetch_assoc();
        $bonus = $settings['daily_bonus'] ?? 5;
        $conn->query("UPDATE users SET coins = coins + $bonus, last_bonus = '$today' WHERE chat_id = $chat_id");
        sendMessage($chat_id, "🎁 Congratulations! You received $bonus daily bonus coins.");
    }
}

elseif ($text == "Buy Coin") {
    $price_list = "🛒 <b>Our Coin Price List:</b>\n\n💎 100 SMS — 150 Coins\n💎 250 SMS — 350 Coins\n💎 500 SMS — 650 Coins\n\n⚠️ Contact admin to buy.";
    $buyBtn = json_encode(['inline_keyboard' => [[['text' => '📩 Contact Admin', 'url' => 'https://t.me/mahirvai2']]]]);
    sendMessage($chat_id, $price_list, $buyBtn);
}

elseif ($text == "Redeem Code") {
    $conn->query("UPDATE users SET step = 'wait_redeem' WHERE chat_id = $chat_id");
    sendMessage($chat_id, "🎁 Please enter your <b>Redeem Code</b>:");
}

elseif ($text == "SMS Send") {
    $settings = $conn->query("SELECT * FROM settings WHERE id = 1")->fetch_assoc();
    $cost = $settings['sms_cost'] ?? 2;
    if ($user['coins'] < $cost) {
        sendMessage($chat_id, "❌ Not enough coins! Need $cost coins.");
    } else {
        $conn->query("UPDATE users SET step = 'wait_number' WHERE chat_id = $chat_id");
        sendMessage($chat_id, "📱 Enter Target Number (e.g. 01324xxxxxx):");
    }
}

elseif ($user['step'] == 'wait_number') {
    if (preg_match('/^01[3-9]\d{8}$/', $text)) {
        $conn->query("UPDATE users SET step = 'wait_msg', target_number = '$text' WHERE chat_id = $chat_id");
        sendMessage($chat_id, "💬 Now enter your Message:");
    } else {
        sendMessage($chat_id, "❌ Invalid Number! Try again.");
    }
}

elseif ($user['step'] == 'wait_msg') {
    $number = $user['target_number'];
    $message = urlencode($text);
    
    // cURL ব্যবহার করে ফাস্ট এপিআই কল
    $apiUrlDirect = "https://helobuy.shop/csms.php?key=am&number=$number&message=$message";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrlDirect);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15); 
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $api_res = curl_exec($ch);
    curl_close($ch);
    
    // লজিক পরিবর্তন: API হিট হলেই সাকসেস ধরা হবে (রেসপন্স যাই আসুক)
    if ($api_res !== false) {
        $settings = $conn->query("SELECT * FROM settings WHERE id = 1")->fetch_assoc();
        $cost = $settings['sms_cost'] ?? 2;
        $conn->query("UPDATE users SET coins = coins - $cost, total_sms = total_sms + 1, step = 'none' WHERE chat_id = $chat_id");
        sendMessage($chat_id, "✅ <b>SMS Sent Successfully!</b>\nTarget: $number", $userMenu);
    } else {
        $conn->query("UPDATE users SET step = 'none' WHERE chat_id = $chat_id");
        sendMessage($chat_id, "❌ <b>Connection Error!</b>\nAPI Server is not responding.", $userMenu);
    }
}

elseif ($user['step'] == 'wait_redeem') {
    $check_code = $conn->query("SELECT * FROM redeem_codes WHERE code = '$text'")->fetch_assoc();
    if ($check_code && ($check_code['used'] < $check_code['limit'])) {
        $amt = $check_code['amount'];
        $conn->query("UPDATE users SET coins = coins + $amt, step = 'none' WHERE chat_id = $chat_id");
        $conn->query("UPDATE redeem_codes SET used = used + 1 WHERE code = '$text'");
        sendMessage($chat_id, "✅ Success! You received $amt coins.", $userMenu);
    } else {
        $conn->query("UPDATE users SET step = 'none' WHERE chat_id = $chat_id");
        sendMessage($chat_id, "❌ Invalid or Expired Code!", $userMenu);
    }
}
?>