<?php
$host = "localhost";
$db_user = "venomxbd_bot";
$db_pass = "venomxbd_bot";
$db_name = "venomxbd_bot";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$botToken = "8319873324:AAEC1oUzzqvfHbd_1PmiHxq5q4Q33r_6syA"; //nijer bot token
$adminId = "7276206449"; //admin chat id diba
$channelUsername = "@mbtcyber"; // @ shoho
$apiUrl = "https://apisell24.top/";// APA DOTO ATA KONO KAJER NA

// Common Function
function sendMessage($chat_id, $message, $keyboard = null) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chat_id&text=".urlencode($message)."&parse_mode=HTML";
    if($keyboard) $url .= "&reply_markup=".$keyboard;
    return file_get_contents($url);
}
?>



API LIMIT BASI NA CAILE BUY KORTA PAREN @MAHIRVAI2
BOT ADMIN PANEL /admin likhla paia jaben