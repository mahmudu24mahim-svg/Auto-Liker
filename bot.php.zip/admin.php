<?php
// admin.php
if ($chat_id == $adminId) {

    // ১. কমান্ড ওভাররাইট লজিক (যেকোনো বাটন চাপলে আগের স্টেপ ক্যানসেল হবে)
    $all_admin_buttons = [
        'Per SMS Coin Set', 'Daily Bonus Set', 'Per Refer Coin Set', 
        'Redeem Code Create', 'User Coin Add', 'Ban User', 'Unban User', 
        'Back to User Menu', '/admin', 'Back to Admin Menu'
    ];

    if (in_array($text, $all_admin_buttons)) {
        $conn->query("UPDATE users SET step = 'none' WHERE chat_id = $adminId");
        // স্টেপ ক্যানসেল হওয়ার পর নিচের লজিকগুলো কাজ করবে
    }

    // --- মেইন মেনু ---
    if ($text == "/admin" || $text == "Back to Admin Menu") {
        $adminKb = json_encode([
            'keyboard' => [
                [['text' => 'Per SMS Coin Set'], ['text' => 'Daily Bonus Set']],
                [['text' => 'Per Refer Coin Set'], ['text' => 'Redeem Code Create']],
                [['text' => 'User Coin Add'], ['text' => 'Ban User']],
                [['text' => 'Unban User'], ['text' => 'Back to User Menu']]
            ], 'resize_keyboard' => true
        ]);
        sendMessage($chat_id, "🛠 <b>Admin Control Panel</b>", $adminKb);
    }

    // ইউজার মেনুতে ফিরে যাওয়া
    elseif ($text == "Back to User Menu") {
        $userMenu = json_encode(['keyboard' => [[['text' => 'SMS Send'], ['text' => 'Account']], [['text' => 'Refer'], ['text' => 'Bonus']], [['text' => 'Redeem Code'], ['text' => 'Buy Coin']]], 'resize_keyboard' => true]);
        sendMessage($chat_id, "Returning to User Menu...", $userMenu);
    }

    // --- সেটিংস সেট কমান্ডসমূহ ---
    elseif ($text == "Per SMS Coin Set") {
        $conn->query("UPDATE users SET step = 'set_sms_cost' WHERE chat_id = $adminId");
        sendMessage($chat_id, "💸 Enter new SMS cost (Numbers only):");
    }
    elseif ($text == "Daily Bonus Set") {
        $conn->query("UPDATE users SET step = 'set_daily_bonus' WHERE chat_id = $adminId");
        sendMessage($chat_id, "🎁 Enter daily bonus amount:");
    }
    elseif ($text == "Per Refer Coin Set") {
        $conn->query("UPDATE users SET step = 'set_ref_coin' WHERE chat_id = $adminId");
        sendMessage($chat_id, "💰 Enter refer bonus amount:");
    }

    // --- ইউজার ম্যানেজমেন্ট ---
    elseif ($text == "User Coin Add") {
        $conn->query("UPDATE users SET step = 'wait_add_id' WHERE chat_id = $adminId");
        sendMessage($chat_id, "👤 Enter User ID to add coins:");
    }
    elseif ($text == "Ban User") {
        $conn->query("UPDATE users SET step = 'wait_ban_id' WHERE chat_id = $adminId");
        sendMessage($chat_id, "🚫 Enter User ID to Ban:");
    }
    elseif ($text == "Unban User") {
        $conn->query("UPDATE users SET step = 'wait_unban_id' WHERE chat_id = $adminId");
        sendMessage($chat_id, "🔓 Enter User ID to Unban:");
    }

    // --- রিডিম কোড জেনারেশন ---
    elseif ($text == "Redeem Code Create") {
        $conn->query("UPDATE users SET step = 'wait_redeem_amt' WHERE chat_id = $adminId");
        sendMessage($chat_id, "💰 Enter Redeem Coin Amount:");
    }

    // --- স্টেপ প্রসেসিং (ইনপুট হ্যান্ডলিং) ---
    else {
        // ১. নাম্বার ভ্যালিডেশন (যেখানে যেখানে শুধু নাম্বার দরকার)
        $number_steps = ['set_sms_cost', 'set_daily_bonus', 'set_ref_coin', 'add_coin_amt', 'wait_redeem_amt', 'wait_redeem_limit', 'wait_add_id', 'wait_ban_id', 'wait_unban_id'];
        
        if (in_array($user['step'], $number_steps) && !is_numeric($text)) {
            sendMessage($chat_id, "⚠️ Invalid Input! Please send only numbers.");
            exit;
        }

        // লজিক প্রসেসিং
        if ($user['step'] == 'set_sms_cost') {
            $conn->query("UPDATE settings SET sms_cost = $text WHERE id = 1");
            sendMessage($chat_id, "✅ SMS Cost Updated: $text coins.");
        } 
        elseif ($user['step'] == 'set_daily_bonus') {
            $conn->query("UPDATE settings SET daily_bonus = $text WHERE id = 1");
            sendMessage($chat_id, "✅ Daily Bonus Updated: $text coins.");
        } 
        elseif ($user['step'] == 'set_ref_coin') {
            $conn->query("UPDATE settings SET refer_coin = $text WHERE id = 1");
            sendMessage($chat_id, "✅ Refer Bonus Updated: $text coins.");
        }
        // Coin Add Step 1
        elseif ($user['step'] == 'wait_add_id') {
            $conn->query("UPDATE users SET step = 'add_coin_amt', target_number = '$text' WHERE chat_id = $adminId");
            sendMessage($chat_id, "💰 How many coins to add for ID $text?");
            exit;
        }
        // Coin Add Step 2
        elseif ($user['step'] == 'add_coin_amt') {
            $target = $user['target_number'];
            $conn->query("UPDATE users SET coins = coins + $text WHERE chat_id = '$target'");
            sendMessage($chat_id, "✅ Success! $text coins added to $target");
            // ইউজারকে নোটিশ পাঠানো
            sendMessage($target, "🔔 <b>Balance Added!</b>\nAdmin has added <b>$text coins</b> to your account.");
        }
        // Ban Logic
        elseif ($user['step'] == 'wait_ban_id') {
            $conn->query("UPDATE users SET is_banned = 1 WHERE chat_id = '$text'");
            sendMessage($chat_id, "✅ User $text banned.");
        }
        // Unban Logic
        elseif ($user['step'] == 'wait_unban_id') {
            $conn->query("UPDATE users SET is_banned = 0 WHERE chat_id = '$text'");
            sendMessage($chat_id, "✅ User $text unbanned.");
        }
        // Redeem Step 1
        elseif ($user['step'] == 'wait_redeem_amt') {
            $conn->query("UPDATE users SET step = 'wait_redeem_limit', target_number = '$text' WHERE chat_id = $adminId");
            sendMessage($chat_id, "👥 How many users can claim this?");
            exit;
        }
        // Redeem Step 2 (Final)
        elseif ($user['step'] == 'wait_redeem_limit') {
            $amt = $user['target_number'];
            $lim = (int)$text;
            $code = strtoupper(substr(md5(time()), 0, 8));
            $conn->query("INSERT INTO redeem_codes (code, amount, `limit`) VALUES ('$code', $amt, $lim)");
            sendMessage($chat_id, "✅ <b>Code Generated!</b>\nCode: <code>$code</code>\nAmount: $amt\nLimit: $lim Users");
        }

        // সব কাজ শেষে স্টেপ ক্লিয়ার করা
        $conn->query("UPDATE users SET step = 'none' WHERE chat_id = $adminId");
    }
}
?>
