<?php
header('Content-Type: application/json; charset=utf-8');

$number = isset($_GET['number']) ? $_GET['number'] : '';
$message = isset($_GET['message']) ? urlencode($_GET['message']) : '';

if (empty($number) || empty($message)) {
    echo json_encode(["status" => "error", "error" => "Missing number or message"]);
    exit;
}

// Target URL
$url = "https://helobuy.shop/csms.php?key=unknown2&number=$number&message=$message";

// cURL diye data ana
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$api_response = curl_exec($ch);
curl_close($ch);

// Eikhane logic: Jodi response-ti JSON hoy, tobe seta decode kore direct dekhabo
$decoded_response = json_decode($api_response, true);

if ($decoded_response !== null) {
    // Jodi server theke JSON ashe, seta direct output hobe
    echo json_encode($decoded_response, JSON_PRETTY_PRINT);
} else {
    // Jodi JSON na hoye sudhu text hoy (jemon "working"), tobe eibhabe dekhabe
    echo json_encode([
        "status" => "response",
        "result" => $api_response
    ], JSON_PRETTY_PRINT);
}
?>
